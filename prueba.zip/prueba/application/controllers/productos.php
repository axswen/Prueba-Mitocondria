<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Productos extends CI_Controller {
    
	function __construct() {
        parent::__construct();
        $this->load->model('producto_model');
        $config = array(
				'upload_path' => "assets/upload/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf",
				'overwrite' => TRUE,
				'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				'max_height' => "768",
				'max_width' => "1024"
			);
		$this->load->library('upload', $config);
		$this->load->helper(array('form', 'url'));
    }

    function index(){

    	$data['productos'] = $this->producto_model->getProductos();
		$this->load->view('productos_view', $data);
    }

    function agregar(){
  		$producto = $this->input->post();
  		$producto_id = $producto['producto_id'];
  		$cantidad = $producto['cantidad'];
  		print_r($producto);
  		exit;
  	}

}