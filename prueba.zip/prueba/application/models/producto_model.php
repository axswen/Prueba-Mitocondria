<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Producto_model extends CI_Model {

    public function construct() {
        parent::__construct();
    }
    
    /**
     * Obtiene todos los productos que tengan stock mayor a 0, que se encuentren activos y no estén eliminados.
     *
     * @param null
     * @return object ($productos)
     **/
    function getProductos(){
    	$this->db->from('productos');
        $query_productos = "SELECT * FROM productos where stock > 0 and activo = 1 and deleted = 0";
		$productos = $this->db->query($query_productos);
		return $productos->result();
    }
}