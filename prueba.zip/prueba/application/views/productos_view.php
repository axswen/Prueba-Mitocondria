<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--colocamos los estilos necesarios para la maquetacion-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/css/bootstrap.css" media="screen" />
	<script src="<?php echo base_url("assets/js/jquery.js"); ?>"></script>
	<title>Productos - Prueba</title>
</head>
<body>
	<main role="main">

		<section class="jumbotron text-center">
			<div class="container">
				<h1 class="jumbotron-heading">Productos</h1>
			</div>
		</section>

		<div class="album py-4 bg-dark">
			<div class="container">
				<div class="row">
					<?php foreach($productos as $producto): ?>
						<div class="col-md-4">
							
							<div class="card mb-4 shadow-sm" style="width: 18rem;">
							  <img class="card-img-top" src="<?php echo base_url() . 'assets/img/' . $producto->foto; ?>" alt="<?php echo $producto->nombre; ?>">
							  <div class="card-body" data-producto-id="<?php echo $producto->id; ?>" >
							    <h5 class="card-title"><?php echo $producto->nombre; ?></h5>
							    <p class="card-text"><?php echo $producto->descripcion; ?></p>
							    <div>
							    	<div class="precio mb-2">
								    	<a href="#" rel="precio" class="btn btn-primary">$<?php echo $producto->precio; ?></a>
							    	</div>

								    <div class="input-group input-group-sm mb-2">
									  <div class="input-group-prepend">
									    <span class="input-group-text" id="inputGroup-sizing-sm">Cantidad</span>
									  </div>
									  <input type="number" rel="cantidad" min="0" max="100" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
									</div>
							    </div>
							    <div class="agregar">
							    	<a href="#" class="btn btn-success">Agregar</a>
							    </div>
							  </div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<script>
			$(document).ready(function() {

				$(document).on('click', '.agregar', function() {
					var _this = $(this);
					var _parent = _this.parents('.card-body');
					var producto_id = _parent.data('producto-id');
					var cantidad = _parent.find('.form-control').val();
					$.ajax({
						type: 'POST',
						url: "productos/agregar",
						data: {
							producto_id: producto_id,
							cantidad: cantidad,
						},
						success: function(response){
							console.log(response);
						}
					});
				});
			});
		</script>
		</main>
	</body>
	</html>